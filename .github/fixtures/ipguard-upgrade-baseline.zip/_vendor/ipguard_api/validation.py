"""Local enrollment input validation; these functions perform no network IO."""

import re

from .errors import InvalidInputError
from .models import AuthIdentifier, IdentifierKind

_EMAIL = re.compile(r"[^\s@]+@[^\s@]+\.[^\s@]+", re.ASCII)
_PHONE = re.compile(r"00[1-9][0-9]{6,14}", re.ASCII)
_CODE = re.compile(r"[0-9]{6}", re.ASCII)
_CLIENT_MARKER = re.compile(
    r"(?:^|[^a-z0-9])(?:cli|node[\s._-]*js|home[\s_-]*assistant|custom[\s_-]*client|codex|poc|proof[\s_-]*of[\s_-]*concept|automation|integration|script|python|curl|bot|macbook|macos|windows|linux|docker|terminal|laptop|desktop|raspberry[\s_-]*pi)(?:$|[^a-z0-9])",
    re.IGNORECASE | re.ASCII,
)


def validate_identifier(identifier: str) -> AuthIdentifier:
    """Preserve email spelling or normalize an international phone to ``00``."""
    if not isinstance(identifier, str) or not identifier.strip():
        raise InvalidInputError(
            "A registered email or international phone is required."
        )
    value = identifier.strip()
    if _EMAIL.fullmatch(value):
        return AuthIdentifier(IdentifierKind.EMAIL, value)
    phone = re.sub(r"[\s().-]", "", value)
    if phone.startswith("+"):
        phone = f"00{phone[1:]}"
    if not _PHONE.fullmatch(phone):
        raise InvalidInputError(
            "Use a registered email or an international phone number."
        )
    return AuthIdentifier(IdentifierKind.PHONE, phone)


def validate_verification_code(code: str) -> str:
    """Require six ASCII digits as text, preserving any leading zero."""
    if not isinstance(code, str) or not _CODE.fullmatch(code):
        raise InvalidInputError("The verification code must contain six ASCII digits.")
    return code


def validate_installation_label(label: str) -> str:
    """Require a personal label without implementation identifiers."""
    if not isinstance(label, str) or not label.strip() or len(label.strip()) > 80:
        raise InvalidInputError(
            "Choose a personal installation name of 1 to 80 characters."
        )
    value = label.strip()
    if _CLIENT_MARKER.search(value):
        raise InvalidInputError(
            "Choose a personal installation name without client markers."
        )
    return value
