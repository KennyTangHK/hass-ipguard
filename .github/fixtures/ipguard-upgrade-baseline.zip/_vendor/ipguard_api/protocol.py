"""Message shapes established by the IPGUARD 3.4.8 Android package."""

import json
import time
from collections.abc import Mapping
from datetime import datetime
from uuid import uuid4

from .errors import InvalidInputError, ProtocolError
from .models import AndroidProfile, AuthIdentifier, Board, Relay, Session, SessionStatus
from .validation import validate_installation_label, validate_verification_code

type Packet = dict[str, object]


def envelope(
    identity: str, event: str, body: Mapping[str, object], token: str | None = None
) -> Packet:
    return {
        "header": {
            "event": event,
            "sender": identity,
            "timestamp": time.time_ns() // 1_000_000,
        },
        "body": {**body, "token": str(uuid4()) if token is None else token},
    }


def hello(identity: str, identifier: AuthIdentifier, session: Session | None) -> Packet:
    # Fixed handset metadata also replaces obsolete saved implementation labels.
    profile = AndroidProfile()
    offset = datetime.now().astimezone().utcoffset()
    data: dict[str, object] = {
        "fcm_token": "",
        "without_sip": True,
        "os_version": profile.os_version,
        "language": profile.language,
        "timezone": int(offset.total_seconds()) if offset else 0,
        "weektypes": [[], [], [], [], [], [], []],
        "connectionInfo": profile.connection_info,
    }
    if session is not None:
        label = validate_installation_label(session.label)
        data.update(
            {
                "username": label if session.status is SessionStatus.ACTIVATED else "",
                "phone": identifier.value if identifier.kind.value == "phone" else "",
                "email": identifier.value if identifier.kind.value == "email" else "",
                "akey": "",
                "code": validate_verification_code(session.verification_code),
            }
        )
    return envelope(
        identity, "hello", {"type": 0, "version": profile.app_version, "data": data}
    )


def identifier_fields(identifier: AuthIdentifier) -> dict[str, object]:
    return {identifier.kind.value: identifier.value}


def packet_event(packet: Packet) -> str:
    header = packet.get("header")
    return str(header.get("event", "")) if isinstance(header, dict) else ""


def packet_body(packet: Packet) -> dict[str, object]:
    body = packet.get("body")
    return body if isinstance(body, dict) else {}


def packet_sender(packet: Packet) -> object:
    header = packet.get("header")
    return header.get("sender") if isinstance(header, dict) else None


def assert_android_metadata(packet: Packet) -> None:
    body, event, profile = packet_body(packet), packet_event(packet), AndroidProfile()
    if event == "hello":
        data = body.get("data")
        if not isinstance(data, dict) or body.get("version") != profile.app_version:
            raise InvalidInputError("Incompatible Android greeting metadata.")
        expected = {
            "os_version": profile.os_version,
            "language": profile.language,
            "connectionInfo": profile.connection_info,
        }
        if any(data.get(key) != value for key, value in expected.items()):
            raise InvalidInputError("Incompatible Android greeting metadata.")
        label = data.get("username")
        if label:
            if not isinstance(label, str):
                raise InvalidInputError("Invalid installation label.")
            validate_installation_label(label)
    if event in ("sp_srv_check_username", "sp_srv_override_username"):
        label = body.get("username")
        if not isinstance(label, str) or body.get("model") != profile.model:
            raise InvalidInputError("Incompatible Android registration metadata.")
        validate_installation_label(label)


def decode_frames(frames: list[bytes]) -> Packet | None:
    for frame in reversed(frames):
        try:
            value = json.loads(frame)
            if isinstance(value, str):
                value = json.loads(value)
        except UnicodeDecodeError, ValueError:
            continue
        if not isinstance(value, dict):
            continue
        if value.get("action") == "register":
            continue
        header, body = value.get("header"), value.get("body")
        if (
            isinstance(header, dict)
            and isinstance(header.get("event"), str)
            and isinstance(body, dict)
        ):
            return value
    # SIP action/register controls and unrelated/noisy frames are not auth replies.
    return None


def _decoded(value: object) -> object:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except ValueError:
            raise ProtocolError("Invalid service data encoding.") from None
    return value


def configuration_password(packet: Packet) -> str | None:
    data = _decoded(packet_body(packet).get("data"))
    item: object = None
    if isinstance(data, list):
        item = data[1] if len(data) > 1 else None
    elif isinstance(data, dict):
        item = data.get("1")
    elif data is not None:
        raise ProtocolError("Unsupported account configuration shape.")
    password = item.get("sip_pwd") if isinstance(item, dict) else None
    return password if isinstance(password, str) and password else None


def relay_inventory(body: Mapping[str, object]) -> tuple[Relay, ...]:
    source = _decoded(body.get("boards") if "boards" in body else body.get("sites"))
    if isinstance(source, list):
        sites: dict[str, object] = {"0": {"name": "", "boards": source}}
    elif isinstance(source, dict):
        sites = source
    else:
        raise ProtocolError(
            "Door inventory has no supported boards or sites structure."
        )
    relays: list[Relay] = []
    seen: set[tuple[str, int]] = set()
    for site_id, site in sites.items():
        if not isinstance(site, dict) or not isinstance(site.get("boards"), list):
            continue
        for item in site["boards"]:
            if (
                not isinstance(item, dict)
                or not isinstance(item.get("identity"), str)
                or not item["identity"]
            ):
                continue
            board = Board(
                identity=item["identity"],
                name=_name(item.get("name")),
                site_id=str(site_id),
                site_name=_name(site.get("name")),
                device_id=_scalar(item.get("device_id")),
                device_type=_scalar(item.get("device_type")),
            )
            access, names = item.get("relay_access_mobile_v2"), item.get("relay_name")
            if not isinstance(access, list):
                continue
            names = names if isinstance(names, list) else []
            pending = bool(item.get("waitConfirmBadgeDigital"))
            for index, permission in enumerate(access):
                if index >= 3 or not isinstance(permission, dict):
                    continue
                identity = (board.identity, index + 1)
                if identity in seen:
                    raise ProtocolError("Ambiguous board relay inventory.")
                seen.add(identity)
                kind = _scalar(permission.get("type"))
                relays.append(
                    Relay(
                        board=board,
                        number=index + 1,
                        name=_name(names[index])
                        if index < len(names)
                        else f"Relay {index + 1}",
                        remote_allowed=not pending and kind in (0, 2, "0", "2"),
                        pending_confirmation=pending,
                        access_type=kind,
                        access_mode=_scalar(permission.get("mode")),
                    )
                )
    return tuple(relays)


def _name(value: object) -> str:
    return value if isinstance(value, str) else ""


def _scalar(value: object) -> int | str | None:
    return (
        value if isinstance(value, (int, str)) and not isinstance(value, bool) else None
    )


def validate_endpoint(endpoint: str) -> None:
    from urllib.parse import urlsplit

    try:
        value = urlsplit(endpoint)
        valid = (
            value.scheme == "tcp"
            and value.hostname
            and value.port
            and not value.path
            and not value.query
            and not value.fragment
            and not value.username
        )
    except ValueError:
        valid = False
    if not valid:
        raise InvalidInputError("Expected a ZeroMQ TCP service endpoint.")
