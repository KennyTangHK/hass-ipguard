"""Generated release dependencies."""
