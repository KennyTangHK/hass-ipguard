# IPGUARD for Home Assistant

**Beta release: 0.1.0b1.** This software is in beta and is not a stable release.

This is an independent community project. It is not affiliated with, sponsored by, or endorsed by IPGUARD, NACD, or Noralsy.

Use it lawfully, only with your own authorized account and buildings or doors you have permission to access and control. Do not use it for unauthorized access or abuse.

**Use at your own risk.** To the extent permitted by applicable law, the software is provided without warranty, and its authors and contributors accept no responsibility or liability for its use. The warranty and liability limitations in the [Apache-2.0 license](LICENSE) apply.

A cloud integration for an authorized IPGUARD account. It provides a release button for each relay that your account can open remotely. Buttons report command acknowledgement; they do not measure whether a door is open or locked. Bluetooth, SIP and video calls are outside this integration's scope.

The project has two independently packaged Apache-2.0 libraries:

- [ipguard-api](https://github.com/KennyTangHK/hass-ipguard/blob/v0.1.0b1/ipguard-api/README.md) owns the asynchronous IPGUARD protocol, enrollment, authenticated connection, discovery and release commands.
- `ha-ipguard`, the package at this repository root, owns Home Assistant setup, account lifecycle and button entities in `custom_components/ipguard`.

[Installation and usage](docs/USAGE.md) explains how to add this repository to HACS as an **Integration**, enable beta versions, and install a published release. GitHub Actions builds and attaches the archive automatically; you do not need to upload a ZIP. Its generated SDK copy avoids depending on an unpublished PyPI package.

[Development](https://github.com/KennyTangHK/hass-ipguard/blob/v0.1.0b1/DEVELOPMENT.md) covers Python setup, tests and publishing beta releases. [Protocol notes](docs/PROTOCOL.md) document the inspected Android app and verification limits. This is a custom community integration and does not claim Home Assistant Core acceptance or an official quality tier.
