# Protocol notes and verification limits

This independent beta project follows the user-supplied IPGUARD Android app 3.4.8 (`com.noralsy.portaphone`) and an earlier local proof of concept. Static inspection covered the native ZeroMQ bridge and Hermes application code. It established message shapes and client behavior, not continued compatibility with the vendor's live service.

The API library implements this sequence:

1. Connect a ZeroMQ DEALER with an installation UUID to `tcp://zmq.campiserveur.com:5579`, send the Android greeting, and request phone/email verification with `sp_srv_check_auth`.
2. Validate the six-digit code using `sp_srv_validate_auth`, then obtain a server public key through `sp_srv_ask_key`.
3. Connect to `tcp://zmq.campiserveur.com:5577` using fresh client CURVE keys and the returned server key. Send the initial secure greeting before `sp_srv_check_username`. Use `sp_srv_override_username` only after explicit replacement consent.
4. Receive and acknowledge `srv_sp_update`, retain the activation credential at `data[1].sip_pwd`, and receive `bc_sp_relays` inventories. Reset notices during pending enrollment are ignored; an activated-installation reset requires reauthentication.
5. Send `sp_brd_open_door` with a one-based relay number and board routing identity only when the current inventory permits remote release. Match `brd_sp_open_door_ack` by token and board sender. A missing acknowledgement is an unknown outcome and is never replayed automatically.

Direct enrollment uses ordinary TCP before the CURVE channel. It is not HTTPS or encrypted onboarding. Saved authorization includes identifiers, UUID, verification code, server key and activation credential; do not share serialized sessions or Home Assistant's private storage.

Only remote-capable relay types are exposed. Bluetooth-only access and pending badge confirmation do not create usable cloud controls. No proven cloud physical door/lock-state event was established, so buttons do not report open/closed or locked/unlocked state. SIP/video are outside this library's implementation.

Server-facing human-readable metadata uses the app's values or a mock Android handset (`Pixel 7`, Android `14`, `WiFi`, locale `en_GB`, app version `3.4.8`). The separate user-entered installation label must be a personal name or Android device name. Home Assistant/project names are kept local; opaque identifiers, keys and tokens are preserved.

Automated tests use synthetic accounts and loopback plaintext/CURVE servers. Disposable Home Assistant containers have external networking disabled. Live account acceptance, credential lifetime, account aliases, simultaneous mobile installations, and a supervised physical release remain field checks. This project is not affiliated with IPGUARD, NACD or Noralsy and does not claim vendor endorsement or Home Assistant Core approval.
